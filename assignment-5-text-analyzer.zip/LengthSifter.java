import java.util.*;
import java.io.*;
public class LengthSifter{
    
    public static void main(String[] args){
        System.out.println("hello world");
        
        /*
         * 3/30/2020
         * don't hard-code the file name,
         * allow the user to provide a file name,
         * either interactively or from the command line
         */
        ArrayList<String> totalwords = countwords("Oliver_Twist.txt");
        int stopwords = 0;
        int uniquewords = 0;
        int uniquewithstop = 0;
        Map<Integer, Integer> words = new HashMap<Integer,Integer>();
        // Total number of words in novel (remember to use a variable for filename)
        System.out.println(totalwords.size() +" words in "+  "Oliver_Twist.txt"+"\n"
                          );
        System.out.println(uniqueWords(totalwords).size() + " unique words, including stop words.\n");
        System.out.println(getnonstopWords(totalwords) + " total non stop-words in "+"Oliver_Twist.txt\n");         
        /*
         * 3/29/2020
         * instead of just printing the size of the return value from excludeStop,
         * save it to a new set declared here in main, then use that set for collecting
         * words by length
         */
        Set<String> excludedwords = excludeStop(totalwords);
        System.out.println(excludedwords.size() + " unique words, excluding stop words." );
        printmap(wordlengths(totalwords)); // should be using unique words here
        System.out.println("\n");
        System.out.println( "The largest group of words have "  +  getlargestValue(wordlengths(totalwords)) + " letters");
        showwordlengths(excludedwords);
        // The above line is me following your instructions, I had to change the parameter in the function but it compiles just fine
    }
    
    public static ArrayList<String> countwords (String file){
        ArrayList<String> words = new ArrayList<>();
        try{
            File filetoread = new File(file);
            Scanner newone = new Scanner(filetoread);
            String line;
            while (newone.hasNextLine()){
                line = newone.nextLine();
                /* the line variable above now has a complete line from the book,
                * it's something like, for example,
                * 
                * "For a long time after it was ushered into this world of sorrow and"
                * 
                * so when it's split, you'll have the separated words in the String[] array
                * the argument to split is just a space -- that right hand side should look
                * like:
                * 
                *  line.split(" ");
                */
                String[] array = line.split(" ") ;
                for (String word: array){
                    words.add(word);
                }
                // use a loop here to add all the elements of array
                // to the list word declared above
            }
        } catch(IOException e){
            e.printStackTrace();
        }
        return words;
    }
    
    public static Set<String> uniqueWords(ArrayList<String> nulist){
        Set<String> unique = new HashSet<String>();
        for (String word:nulist){
            unique.add(word);
        }
        return unique;
    }
    
    public static int getnonstopWords(ArrayList<String> newlist){
        ArrayList<String> nonstop = new ArrayList<>();
        ArrayList<String> words = countwords("stop_words.txt");
        for (String word: newlist){
            boolean answer= words.contains(word);
            if ( answer == false ){
                nonstop.add(word);
            }
        }
        return nonstop.size();
    }
    
    public static Set<String> excludeStop(ArrayList<String> nulist){
        Set<String> uniqueset = uniqueWords(nulist);
        ArrayList<String> words = countwords("stop_words.txt");
          for (String word:words){
              if (uniqueset.contains(word) == true){
                  uniqueset.remove(word);
              }
          }
          return uniqueset;
    } 
    
    public static Map<Integer,Integer> wordlengths(ArrayList<String> list){
        Map<Integer,Integer> intmap = new HashMap<Integer,Integer>();
        for (String word: list){
            if(intmap.containsKey(word.length()) == false    ){
                intmap.put(word.length(), 1   )  ;
            } else if (intmap.containsKey(word.length()) == true){
                intmap.put(word.length(),intmap.get(word.length()) + 1    );
            }
        }
        return intmap;     
    }
    
    public static int getlargestValue(Map<Integer,Integer> map){
        int  v =0;
        int key = 0;
        for (int val:map.keySet()){
            if ( map.get(val) >v){
                v = map.get(val);
                key = val;
            }
        }
        return key;
    }
    
    public static void printmap(Map<Integer,Integer> printmap){
        for (int val:printmap.keySet()){
            System.out.print(val+"\t" +printmap.get(val) +" words\n");
        }
    }
    
    //This is the function I emailed you about
    public static void showwordlengths(Set<String> list){
        Scanner m = new Scanner(System.in);
        String word = "Y";
            while ( word.equals("Y")){
                System.out.println("Show words of what length: ");
                {
                /* 
                 * 3/29/2020
                 * when a program uses 'cooked' (i.e. parsed) input
                 * such as nextInt, nextDouble, or some others,
                 * then subsequently uses 'whole line' input such as
                 * for word below, there's an unconsumed newline character
                 * left from the previous input -- aka the 'trailing newline'
                 * 
                 * the program has to consume it (it's sort of like
                 * when reading a .csv file and the program has to
                 * read the headers, even if it doesn't do anything with them)
                 * 
                 * _One_ way to consume the trailing newline is to
                 * call m.nextLine() somewhere _after_ the call to nextInt()
                 * and _before_ the call to nextLine()
                 * 
                 * _Another_ way is to not use input methods that leave
                 * trailing newlines, and have the application do
                 * its own parsing. For example, instead of
                 *     int val = keyb.nextInt(); // leaves a trailing newline
                 * just read the whole line and parse it yourself
                 *     int val = Integer.parseInt(keyb.nextLine()); // newline consumed
                 * 
                 */
                }
                int num = Integer.parseInt(m.nextLine());
                for(String n: list){
                    if(n.length() == num){
                        /*
                         * 4/10/2020
                         * this function is doing the right thing,
                         * but it's really hard to tell when it runs,
                         * because the output all runs together
                         * the statement below needs something
                         * so separate words don't run together
                         */
                        System.out.print(n);
                    }
                }
                System.out.println("\n");
                System.out.println("Another? Y/N ");
                word = m.nextLine().toUpperCase();
            }
        
    }
    
    
    
    
    
    
    
    
    
}